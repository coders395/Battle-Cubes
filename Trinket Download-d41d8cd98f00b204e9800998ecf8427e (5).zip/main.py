import pygame# controls = (a key) to move player and the (r key) does nothing
import random
import math

pygame.init()
screen = pygame.display.set_mode((1280, 720))
clock = pygame.time.Clock()
running = True

# Player
rect = pygame.Rect(575, 299, 23, 8)
player_speed = 3
moving = False
dx, dy = 0, 0

# Enemy
enemy = pygame.Rect(100, 20, 76, 30)
enemy_speed = 2
enemy = pygame.Rect(0, 720 - 30, 49, 39)
# Obstacles
obstacles = [
    pygame.Rect(400, 300, 80, 30),
    pygame.Rect(600, 150, 50, 120),
    pygame.Rect(300, 520, 120, 68),
]

font = pygame.font.SysFont(None, 48)
lost = False

show_r_message = ""

while running:# ai assisted
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a and not moving and not lost:
                dx = random.choice([-1, 0, 1])
                dy = random.choice([-1, 0, 1])
                while dx == 0 and dy == 0:
                    dx = random.choice([-1, 0, 1])
                    dy = random.choice([-1, 0, 1])
                moving = True
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_a:
                moving = False
                          
            if event.key == pygame.K_r:
                print("r")
                show_r_message = True
                r_message_time = pygame.time.get_ticks()
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_a:
                moving = False

    if moving and not lost:
        rect.x += dx * player_speed
        rect.y += dy * player_speed
        # Bounce on window edges
        if rect.left < 0 or rect.right > 1280:
            dx = -dx
        if rect.top < 0 or rect.bottom > 720:
            dy = -dy
        # Check collision with obstacles
        for obs in obstacles:
            if rect.colliderect(obs):
                moving = False
                break

    if not lost:
        # Enemy chases player
        ex, ey = enemy.x, enemy.y
        px, py = rect.x, rect.y
        dist = math.hypot(px - ex, py - ey)
        if dist != 0:
            enx = (px - ex) / dist
            eny = (py - ey) / dist
            enemy.x += int(enx * enemy_speed)
            enemy.y += int(eny * enemy_speed)

    #  collision with enemy
    if rect.colliderect(enemy):
        lost = True
        moving = False

    # Draw everything
    screen.fill((0, 50, 0))
    pygame.draw.rect(screen, (0, 0, 255), rect)   # Player (blue)
    pygame.draw.rect(screen, (255, 0, 0), enemy)  # Enemy (red)
    for obs in obstacles:
        pygame.draw.rect(screen, (255, 165, 0), obs)  # Obstacles (orange)

    if lost:
        msg_surface = font.render('You Lose', True, (255, 0, 0))# ai assisted
        screen.blit(msg_surface, (
            screen.get_width() // 2 - msg_surface.get_width() // 2,
            screen.get_height() // 2 - msg_surface.get_height() // 2
        ))
    else:
        instr = font.render("Press A for random move. Avoid the red!", True, (200, 200, 255))
        screen.blit(instr, (10, 10))
 # Show the R key message for 2 seconds
    if show_r_message and pygame.time.get_ticks() - r_message_time < 2000:
        msg_surface = font.render('this doesnt do anything', True, (25, 250, 245))
        screen.blit(msg_surface, (screen.get_width() // 2 - msg_surface.get_width() // 26, 50))
    elif show_r_message:
        show_r_message = False# end of ai assistent
        
    pygame.display.flip()
    clock.tick(80)

pygame.quit()
